// SPDX-License-Identifier: ISC
/* Copyright (C) 2020 MediaTek Inc. */

#include <linux/sched/clock.h>
#include "mt7921.h"

static int
mt7921_reg_set(void *data, u64 val)
{
	struct mt792x_dev *dev = data;

	mt792x_mutex_acquire(dev);
	mt76_wr(dev, dev->mt76.debugfs_reg, val);
	mt792x_mutex_release(dev);

	return 0;
}

static int
mt7921_reg_get(void *data, u64 *val)
{
	struct mt792x_dev *dev = data;

	mt792x_mutex_acquire(dev);
	*val = mt76_rr(dev, dev->mt76.debugfs_reg);
	mt792x_mutex_release(dev);

	return 0;
}

DEFINE_DEBUGFS_ATTRIBUTE(fops_regval, mt7921_reg_get, mt7921_reg_set,
			 "0x%08llx\n");


enum {
        TM_SWITCH_MODE,
        TM_SET_AT_CMD,
        TM_QUERY_AT_CMD,
};

enum {
        MT7921_TM_NORMAL,
        MT7921_TM_TESTMODE,
        MT7921_TM_ICAP,
        MT7921_TM_ICAP_OVERLAP,
        MT7921_TM_WIFISPECTRUM,
};

struct mt7921_rftest_cmd {
        u8 action;
        u8 rsv[3];
        __le32 param0;
        __le32 param1;
} __packed;

struct mt7921_tm_cmd {
        u8 action;
        u32 param0;
        u32 param1;
};

struct mt7921_tm_evt {
        u32 param0;
        u32 param1;
};

unsigned char
usb_read_wifi_mcu_pc(struct mt76_dev *dev,  uint8_t ucPcLogSel, uint32_t *pu4RetVal)
{

        #define CONNAC2X_UDMA_BASE              	0x74000000
        #define CONNAC2X_UDMA_TX_QSEL           	(CONNAC2X_UDMA_BASE + 0x08) /* 0008 */
        #define CONNAC2X_UDMA_RESET             	(CONNAC2X_UDMA_BASE + 0x14) /* 0014 */
        #define CONNAC2X_UDMA_WLCFG_1           	(CONNAC2X_UDMA_BASE + 0x0C) /* 000c */
        #define CONNAC2X_UDMA_WLCFG_0           	(CONNAC2X_UDMA_BASE + 0x18) /* 0018 */

        /* For support mcu debug mechanism. +*/
        #define USB_CTRL_EN          	           	(1 << 31)
        #define CONNAC2X_UDMA_CONDBGCR_DATA     	(CONNAC2X_UDMA_BASE + 0xA18) /* 0A18 */
        #define CONNAC2X_UDMA_CONDBGCR_SEL      	(CONNAC2X_UDMA_BASE + 0xA1C) /* 0A1C */

	#define CONNAC2X_UDMA_MCU_PC_LOG_MASK   	(0x3F)
	#define CONNAC2X_UDMA_MCU_PC_LOG_SHIFT  	(16)

	#define PC_IDX_SWH(val, idx, mask, shift) 	((val & (~(mask << shift))) | ((mask & idx) << shift))

        uint32_t u4Val 		= 0x00;

        if (pu4RetVal == NULL){
                return 0x00;
	}

        u4Val			= __mt76_rr(dev, CONNAC2X_UDMA_CONDBGCR_SEL);

        u4Val 			= PC_IDX_SWH(u4Val, ucPcLogSel, CONNAC2X_UDMA_MCU_PC_LOG_MASK, CONNAC2X_UDMA_MCU_PC_LOG_SHIFT);

        __mt76_wr(dev, CONNAC2X_UDMA_CONDBGCR_SEL, u4Val);
        *pu4RetVal		= __mt76_rr(dev, CONNAC2X_UDMA_CONDBGCR_DATA);

        return 0x00;
}

/** read the PC on mt7921e **/
static uint8_t
pcie_read_wifi_mcu_pc(struct mt76_dev *dev, uint8_t ucPcLogSel, uint32_t *pu4RetVal)
{

	#define PCIE_CTRL_EN            (1 << 28)
	#define CONNAC2X_PCIE_CONDBGCR_CTRL             (0xE009C)
	#define CONNAC2X_PCIE_CONDBGCR_DATA             (0xE0204)
	#define CONNAC2X_PCIE_CONDBGCR_LR_DATA          (0xE0208)
	#define CONNAC2X_PCIE_CONDBGCR_SEL              (0xE0090)
	#define CONNAC2X_PCIE_MCU_PC_LOG_MASK   (0x3F)
	#define CONNAC2X_PCIE_MCU_PC_LOG_SHIFT  (2)
	#define CONNAC2X_PCIE_MCU_LR_LOG_MASK   (0x3F)
	#define CONNAC2X_PCIE_MCU_LR_LOG_SHIFT  (8)

        uint32_t u4Val            = 0x00;

        if (pu4RetVal == NULL){
                return 0x00;
        }

        u4Val                     = __mt76_rr(dev, CONNAC2X_PCIE_CONDBGCR_SEL);
        u4Val                     = PC_IDX_SWH(u4Val, ucPcLogSel, CONNAC2X_PCIE_MCU_PC_LOG_MASK, CONNAC2X_PCIE_MCU_PC_LOG_SHIFT);
        __mt76_wr(dev, CONNAC2X_PCIE_CONDBGCR_SEL, u4Val);
        *pu4RetVal                = __mt76_rr(dev, CONNAC2X_PCIE_CONDBGCR_DATA);

        return 0x1;
}

static u_int8_t
pcie_read_wifi_mcu_lr(struct mt76_dev *dev, uint8_t ucPcLogSel, uint32_t *pu4RetVal)
{
        uint32_t u4Val            = 0x00;

        if (pu4RetVal == NULL){
                return 0x00;
        }

        u4Val                     = __mt76_rr(dev, CONNAC2X_PCIE_CONDBGCR_SEL);
        u4Val                     = PC_IDX_SWH(u4Val, ucPcLogSel, CONNAC2X_PCIE_MCU_LR_LOG_MASK, CONNAC2X_PCIE_MCU_LR_LOG_SHIFT);
        __mt76_wr(dev, CONNAC2X_PCIE_CONDBGCR_SEL, u4Val);
        *pu4RetVal                = __mt76_rr(dev, CONNAC2X_PCIE_CONDBGCR_LR_DATA);

        return 0x1;
}


static int
mt76_cpu_state_get(struct seq_file *s, void *val)
{
	struct mt76_dev *dev 	= (struct mt76_dev *)dev_get_drvdata(s->private);
	uint32_t i   		= 0x00;
        uint32_t u4Val    	= 0x00;

	/** switch between the right device for dumping the PC, special registers and so on.. **/

	if( is_mt7915(dev) ){

	}

	if( is_mt7986(dev) ){	/** apply also to mt7981 **/

	}

	if( is_mt7921(dev) || is_mt7922(dev) ){
		/** for mt7921/22 we need to choose if the device is USB or PCIe based. **/
		if( mt76_is_usb(dev) ){
			#define CONNAC2X_UDMA_BASE        	0x74000000
			#define CONNAC2X_UDMA_TX_QSEL     	(CONNAC2X_UDMA_BASE + 0x08) /* 0008 */
			#define CONNAC2X_UDMA_RESET       	(CONNAC2X_UDMA_BASE + 0x14) /* 0014 */
			#define CONNAC2X_UDMA_WLCFG_1     	(CONNAC2X_UDMA_BASE + 0x0C) /* 000c */
			#define CONNAC2X_UDMA_WLCFG_0     	(CONNAC2X_UDMA_BASE + 0x18) /* 0018 */

			/* For support mcu debug mechanism. +*/
			#define USB_CTRL_EN             	(1 << 31)
			#define CONNAC2X_UDMA_CONDBGCR_DATA     (CONNAC2X_UDMA_BASE + 0xA18) /* 0A18 */
			#define CONNAC2X_UDMA_CONDBGCR_SEL      (CONNAC2X_UDMA_BASE + 0xA1C) /* 0A1C */
			#define CONNAC2X_UDMA_WM_MONITER_SEL    (~(0x40000000))
			#define CONNAC2X_UDMA_PC_MONITER_SEL    (~(0x20000000))
			#define CONNAC2X_UDMA_LR_MONITER_SEL    (0x20000000)
			#define CONNAC2X_UDMA_MCU_PC_LOG_MASK   (0x3F)
			#define CONNAC2X_UDMA_MCU_PC_LOG_SHIFT  (16)
			/* For support mcu debug mechanism. -*/

			/* For support CFG_SUPPORT_DEBUG_SOP +*/
			#define CONNAC2X_UDMA_BT_DBG_STATUS     (CONNAC2X_UDMA_BASE + 0xA00) /* 0A00 */
			#define CONNAC2X_UDMA_BT_DBG_SEL        (CONNAC2X_UDMA_BASE + 0xA04) /* 0A04 */
			#define CONNAC2X_UDMA_DBG_STATUS        (CONNAC2X_UDMA_BASE + 0xA10) /* 0A10 */
			#define CONNAC2X_UDMA_DBG_SEL           (CONNAC2X_UDMA_BASE + 0xA14) /* 0A14 */

			#define CURRENT_PC 			0x3F
			#define PC_LOG_IDX 			0x20
			#define PC_LOG_NUM 			32

        		/* Enable USB mcu debug function. */
        		u4Val	= __mt76_rr(dev, CONNAC2X_UDMA_CONDBGCR_SEL);
        		u4Val  |= USB_CTRL_EN;
        		u4Val  &= CONNAC2X_UDMA_WM_MONITER_SEL;
        		u4Val  &= CONNAC2X_UDMA_PC_MONITER_SEL;
        		__mt76_wr(dev, CONNAC2X_UDMA_CONDBGCR_SEL, u4Val);

        		usb_read_wifi_mcu_pc(dev, CURRENT_PC, &u4Val);

        		seq_printf(s, "mt7921u: Current PC LOG: 0x%08x\n", u4Val);

                	for (i = 0; i < PC_LOG_NUM; i++) {
                        	usb_read_wifi_mcu_pc(dev, i, &u4Val);
                        	seq_printf(s, "mt7921u: PC log(%d)=0x%08x\n", i, u4Val);
                	}

                	/* Switch to LR. */
                	u4Val	= __mt76_rr(dev, CONNAC2X_UDMA_CONDBGCR_SEL);
                	u4Val  |= CONNAC2X_UDMA_LR_MONITER_SEL;
                	__mt76_wr(dev, CONNAC2X_UDMA_CONDBGCR_SEL, u4Val);

                	usb_read_wifi_mcu_pc(dev, PC_LOG_IDX, &u4Val);
                	seq_printf(s, "mt7921u: LR log contorl=0x%08x\n", u4Val);
                	for (i = 0; i < PC_LOG_NUM; i++) {
                        	usb_read_wifi_mcu_pc(dev, i, &u4Val);
                        	seq_printf(s, "mt7921u: LR log(%d)=0x%08x\n", i, u4Val);
                	}
        		/* Disable USB mcu debug function. */
        		u4Val	= __mt76_rr(dev, CONNAC2X_UDMA_CONDBGCR_SEL);
        		u4Val  &= ~USB_CTRL_EN;
        		__mt76_wr(dev, CONNAC2X_UDMA_CONDBGCR_SEL, u4Val);

		}else if( dev_is_pci(dev) || 1 ){	/** exclude SDIO based hardware **/
			printk("mt7921 pcie");
      			/* Enable PCIE mcu debug function. */
        		u4Val	= __mt76_rr(dev, CONNAC2X_PCIE_CONDBGCR_CTRL);
        		u4Val  |= PCIE_CTRL_EN;
        		__mt76_wr(dev, CONNAC2X_PCIE_CONDBGCR_CTRL, u4Val);

        		pcie_read_wifi_mcu_pc(dev, CURRENT_PC, &u4Val);

        		seq_printf(s, "mt7921e: Current PC LOG: 0x%08x\n", u4Val);
            pcie_read_wifi_mcu_pc(dev, PC_LOG_IDX, &u4Val);
            seq_printf(s, "mt7921e: PC log contorl=0x%08x\n", u4Val);
            for (i = 0; i < PC_LOG_NUM; i++) {
                pcie_read_wifi_mcu_pc(dev, i, &u4Val);
                seq_printf(s, "mt7921e: PC log(%d)=0x%08x\n", i, u4Val);
            }
	                /* Read LR log. */
        	        pcie_read_wifi_mcu_lr(dev, PC_LOG_IDX, &u4Val);
                	seq_printf(s, "mt7921e: LR log contorl=0x%08x\n", u4Val);
                	for (i = 0; i < PC_LOG_NUM; i++) {
                        	pcie_read_wifi_mcu_lr(dev, i, &u4Val);
	                        seq_printf(s, "mt7921e: LR log(%d)=0x%08x\n", i, u4Val);
                	}

        		/* Disable PCIE mcu debug function. */
        		u4Val	= __mt76_rr(dev, CONNAC2X_PCIE_CONDBGCR_CTRL);
        		u4Val  &= ~PCIE_CTRL_EN;
        		__mt76_wr(dev, CONNAC2X_PCIE_CONDBGCR_CTRL, u4Val);
		}
	}

	if( is_mt7925(dev) ){
		#define CONN_DBG_CTL_WF_MCU_DBGOUT_SEL_WF_MCU_DBGOUT_SEL_ADDR \
        		CONN_DBG_CTL_WF_MCU_DBGOUT_SEL_ADDR
		#define CONN_DBG_CTL_WF_MCU_DBGOUT_SEL_WF_MCU_DBGOUT_SEL_MASK \
        		0x00000007
		#define CONN_DBG_CTL_WF_MCU_DBGOUT_SEL_WF_MCU_DBGOUT_SEL_SHFT \
        		0
		#define CONN_DBG_CTL_WF_MCU_GPR_BUS_DBGOUT_LOG_WF_MCU_GPR_BUS_DBGOUT_LOG_ADDR \
        		CONN_DBG_CTL_WF_MCU_GPR_BUS_DBGOUT_LOG_ADDR
		#define CONN_DBG_CTL_WF_MCU_GPR_BUS_DBGOUT_LOG_WF_MCU_GPR_BUS_DBGOUT_LOG_MASK \
        		0xFFFFFFFF
		#define CONN_DBG_CTL_WF_MCU_GPR_BUS_DBGOUT_LOG_WF_MCU_GPR_BUS_DBGOUT_LOG_SHFT \
		        0
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_SEL_WF_MCU_DBG_PC_LOG_SEL_ADDR \
		        CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_SEL_ADDR
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_SEL_WF_MCU_DBG_PC_LOG_SEL_MASK \
	       	 	0x0000003F
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_SEL_WF_MCU_DBG_PC_LOG_SEL_SHFT \
      	  		0
		#define CONN_DBG_CTL_WF_MCU_GPR_BUS_DBGOUT_LOG_WF_MCU_GPR_BUS_DBGOUT_LOG_ADDR \
	        	CONN_DBG_CTL_WF_MCU_GPR_BUS_DBGOUT_LOG_ADDR
		#define CONN_DBG_CTL_WF_MCU_GPR_BUS_DBGOUT_LOG_WF_MCU_GPR_BUS_DBGOUT_LOG_MASK \
	        	0xFFFFFFFF
		#define CONN_DBG_CTL_WF_MCU_GPR_BUS_DBGOUT_LOG_WF_MCU_GPR_BUS_DBGOUT_LOG_SHFT \
	        	0
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_SEL_WF_MCU_DBG_PC_LOG_SEL_ADDR \
	        	CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_SEL_ADDR
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_SEL_WF_MCU_DBG_PC_LOG_SEL_MASK \
	        	0x0000003F
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_SEL_WF_MCU_DBG_PC_LOG_SEL_SHFT \
	        	0
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_WF_MCU_DBG_PC_LOG_ADDR \
        		CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_ADDR
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_WF_MCU_DBG_PC_LOG_MASK \
        		0xFFFFFFFF
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_WF_MCU_DBG_PC_LOG_SHFT \
        		0
		#define CONN_DBG_CTL_WF_MCU_DBG_GPR_LOG_SEL_WF_MCU_DBG_GPR_LOG_SEL_ADDR \
        		CONN_DBG_CTL_WF_MCU_DBG_GPR_LOG_SEL_ADDR
		#define CONN_DBG_CTL_WF_MCU_DBG_GPR_LOG_SEL_WF_MCU_DBG_GPR_LOG_SEL_MASK \
        		0x0000003F
		#define CONN_DBG_CTL_WF_MCU_DBG_GPR_LOG_SEL_WF_MCU_DBG_GPR_LOG_SEL_SHFT \
        		0
		#define CONN_DBG_CTL_WF_CORE_PC_INDEX_FR_HIF_WF_CORE_PC_INDEX_FR_HIF_ADDR \
        		CONN_DBG_CTL_WF_CORE_PC_INDEX_FR_HIF_ADDR
		#define CONN_DBG_CTL_WF_CORE_PC_INDEX_FR_HIF_WF_CORE_PC_INDEX_FR_HIF_MASK \
        		0x00001FFF
		#define CONN_DBG_CTL_WF_CORE_PC_INDEX_FR_HIF_WF_CORE_PC_INDEX_FR_HIF_SHFT \
        		0
		#define CONN_INFRA_REMAPPING_OFFSET                    0x64000000
		#define CONN_DBG_CTL_BASE 							\
	        	(0x18023000 + CONN_INFRA_REMAPPING_OFFSET)
		#define CONN_DBG_CTL_CONN_INFRA_BUS_CLK_DETECT_ADDR 				\
        		(CONN_DBG_CTL_BASE + 0x000)
		#define CONN_DBG_CTL_CONN_INFRA_BUS_TIMEOUT_IRQ_ADDR 				\
        		(CONN_DBG_CTL_BASE + 0x400)
		#define CONN_DBG_CTL_WF_MCU_DBGOUT_SEL_ADDR 					\
        		(CONN_DBG_CTL_BASE + 0x604)
		#define CONN_DBG_CTL_WF_MCU_GPR_BUS_DBGOUT_LOG_ADDR 				\
        		(CONN_DBG_CTL_BASE + 0x608)
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_SEL_ADDR 				\
        		(CONN_DBG_CTL_BASE + 0x60C)
		#define CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_ADDR 					\
        		(CONN_DBG_CTL_BASE + 0x610)
		#define CONN_DBG_CTL_WF_MCU_DBG_GPR_LOG_SEL_ADDR 				\
        		(CONN_DBG_CTL_BASE + 0x614)
		#define CONN_DBG_CTL_WF_CORE_PC_INDEX_FR_HIF_ADDR 				\
        		(CONN_DBG_CTL_BASE + 0x620)
		#define CONN_DBG_CTL_WF_MCUSYS_INFRA_VDNR_GEN_DEBUG_CTRL_AO_DEBUGSYS_CTRL_ADDR 	\
       			(CONN_DBG_CTL_BASE + 0x628)
		#define CONN_DBG_CTL_WF_MCUSYS_INFRA_VDNR_GEN_DEBUG_CTRL_AO_BUS_TIMEOUT_IRQ_ADDR \
        		(CONN_DBG_CTL_BASE + 0x62C)
		#define CONN_DBG_CTL_WF_VON_DEBUG_OUT_ADDR 					\
		        (CONN_DBG_CTL_BASE + 0x638)

		#undef  PC_LOG_NUM
        	#define PC_LOG_NUM                      35
        	#define GPR_LOG_NUM                     35

		#define HAL_MCR_WR_FIELD(_prAdapter, _u4Offset, _u4FieldVal, _ucShft, _u4Mask) 	\
		{ 										\
        	uint32_t u4CrValue = 0; 							\
        	u4CrValue = __mt76_rr(_prAdapter, _u4Offset); 					\
        	u4CrValue &= (~_u4Mask); 							\
        	u4CrValue |= ((_u4FieldVal << _ucShft) & _u4Mask); 				\
        	__mt76_wr(_prAdapter, _u4Offset, u4CrValue); 					\
		}

		#define CPUPCR_LOG_NUM  5
		#define CPUPCR_BUF_SZ   50

        	uint32_t var_pc 	= 0;
        	uint32_t var_lp 	= 0;
        	uint64_t log_sec 	= 0;
        	uint64_t log_nsec 	= 0;
        	char log_buf_pc[CPUPCR_LOG_NUM][CPUPCR_BUF_SZ];
        	char log_buf_lp[CPUPCR_LOG_NUM][CPUPCR_BUF_SZ];

        	HAL_MCR_WR_FIELD(dev,
                	CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_ADDR,
                	0x3F,
                	CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_WF_MCU_DBG_PC_LOG_SHFT,
                	CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_WF_MCU_DBG_PC_LOG_MASK);

		      HAL_MCR_WR_FIELD(dev,
                	CONN_DBG_CTL_WF_MCU_DBG_GPR_LOG_SEL_ADDR,
                	0x3F,
                	CONN_DBG_CTL_WF_MCU_DBG_GPR_LOG_SEL_WF_MCU_DBG_GPR_LOG_SEL_SHFT,
                	CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_WF_MCU_DBG_PC_LOG_MASK);

        	HAL_MCR_WR_FIELD(dev,
                	CONN_DBG_CTL_WF_MCU_DBGOUT_SEL_ADDR,
                	0x0,
                	CONN_DBG_CTL_WF_MCU_DBGOUT_SEL_WF_MCU_DBGOUT_SEL_SHFT,
                	CONN_DBG_CTL_WF_MCU_DBGOUT_SEL_WF_MCU_DBGOUT_SEL_MASK);

        	for (i = 0; i < CPUPCR_LOG_NUM; i++) {
                	log_sec 	= local_clock();
                	log_nsec 	= do_div(log_sec, 1000000000)/1000;

                	var_pc		= __mt76_rr(dev, CONN_DBG_CTL_WF_MCU_DBG_PC_LOG_ADDR);

                	var_lp		= __mt76_rr(dev, CONN_DBG_CTL_WF_MCU_GPR_BUS_DBGOUT_LOG_ADDR);

                	snprintf(log_buf_pc[i],
                        	CPUPCR_BUF_SZ,
                            	"%llu.%06llu/0x%08x;",
                            	log_sec,
                            	log_nsec,
                            	var_pc
			);

                	snprintf(log_buf_lp[i],
                            	CPUPCR_BUF_SZ,
                            	"%llu.%06llu/0x%08x;",
                            	log_sec,
                            	log_nsec,
                            	var_lp);
		}
       		seq_printf(s, "mt7925: wm pc=%s%s%s%s%s\n", log_buf_pc[0], log_buf_pc[1], log_buf_pc[2], log_buf_pc[3], log_buf_pc[4]);
		seq_printf(s, "mt7925: wm lp=%s%s%s%s%s\n", log_buf_lp[0], log_buf_lp[1], log_buf_lp[2], log_buf_lp[3], log_buf_lp[4]);
	}
	return 0;
}

	struct TX_TONE_PARAM_T {
	        uint8_t ucAntIndex;
	        uint8_t ucToneType;
	        uint8_t ucToneFreq;
	        uint8_t ucDbdcIdx;
	        int32_t i4DcOffsetI;
	        int32_t i4DcOffsetQ;
	        uint32_t u4Band;
	};

	struct CONTINUOUS_TX_PARAM_T {
	        uint8_t ucCtrlCh;
	        uint8_t ucCentralCh;
	        uint8_t ucBW;
	        uint8_t ucAntIndex;
	        uint16_t u2RateCode;
	        uint8_t ucBand;
	        uint8_t ucTxfdMode;
	};

	struct TX_TONE_POWER_GAIN_T {
	        uint8_t ucAntIndex;
	        uint8_t ucTonePowerGain;
	        uint8_t ucBand;
	        uint8_t aucReserved[1];
	};

	struct EXT_CMD_RDD_ON_OFF_CTRL_T {
	        uint8_t ucDfsCtrl;
	        uint8_t ucRddIdx;
	        uint8_t ucRddRxSel;
	        uint8_t ucSetVal;
	        uint8_t aucReserved[4];
	};

	struct SET_ADC_T {
        	uint32_t  u4ChannelFreq;
        	uint8_t ucAntIndex;
        	uint8_t ucBW;
        	uint8_t   ucSX;
        	uint8_t ucDbdcIdx;
        	uint8_t ucRunType;
        	uint8_t ucFType;
	        uint8_t aucReserved[2];         /* Reserving For future */
	};

	struct SET_RX_GAIN_T {
        	uint8_t ucLPFG;
        	uint8_t   ucLNA;
        	uint8_t ucDbdcIdx;
        	uint8_t ucAntIndex;
	};

	struct SET_TTG_T {
	        uint32_t  u4ChannelFreq;
	        uint32_t  u4ToneFreq;
	        uint8_t ucTTGPwrIdx;
	        uint8_t ucDbdcIdx;
	        uint8_t ucXtalFreq;
	        uint8_t aucReserved[1];
	};

	struct TTG_ON_OFF_T {
        	uint8_t ucTTGEnable;
        	uint8_t ucDbdcIdx;
        	uint8_t ucAntIndex;
        	uint8_t aucReserved[1];
	};

	struct RBIST_CAP_START_T {
        	uint32_t u4Trigger;
        	uint32_t u4RingCapEn;
        	uint32_t u4TriggerEvent;
        	uint32_t u4CaptureNode;
        	uint32_t u4CaptureLen;    	/* Unit : IQ Sample */
        	uint32_t u4CapStopCycle;  	/* Unit : IQ Sample */
        	uint32_t u4MacTriggerEvent;
        	uint32_t u4SourceAddressLSB;
        	uint32_t u4SourceAddressMSB;
        	uint32_t u4BandIdx;
        	uint32_t u4BW;
        	uint32_t u4EnBitWidth;		/* 0:32bit, 1:96bit, 2:128bit */
        	uint32_t u4Architech;		/* 0:on-chip, 1:on-the-fly */
        	uint32_t u4PhyIdx;
	        uint32_t u4EmiStartAddress;
       	 	uint32_t u4EmiEndAddress;
       	 	uint32_t u4EmiMsbAddress;
	        uint32_t u4CapSource;
	        uint32_t u4Reserved[2];
	};


	struct RF_TEST_CALIBRATION_T {
        	uint32_t        u4FuncData;
        	uint8_t ucDbdcIdx;
        	uint8_t aucReserved[3];
	};

	struct RBIST_DUMP_IQ_T {
	        uint32_t u4WfNum;
	        uint32_t u4IQType;
	        uint32_t u4IcapCnt; 		/*IQ Sample Count*/
	        uint32_t u4IcapDataLen;
	        uint8_t *pucIcapData;
	};

	struct RBIST_DUMP_RAW_DATA_T {
        	uint32_t u4Address;
        	uint32_t u4AddrOffset;
        	uint32_t u4Bank;
        	uint32_t u4BankSize;/* Uint:Kbytes */
        	uint32_t u4Reserved[8];
	};

	struct PARAM_MTK_WIFI_TEST_STRUCT_EXT_T {
        	uint32_t u4FuncIndex;
        	union {
        	        uint32_t u4FuncData;
        	        uint32_t u4CalDump;
        	        struct RF_TEST_CALIBRATION_T rCalParam;
        	        struct TX_TONE_PARAM_T rTxToneParam;
        	        struct CONTINUOUS_TX_PARAM_T rConTxParam;
        	        struct TX_TONE_POWER_GAIN_T rTxToneGainParam;
        	        struct RBIST_CAP_START_T rICapInfo;
        	        struct RBIST_DUMP_RAW_DATA_T rICapDump;
        	        struct EXT_CMD_RDD_ON_OFF_CTRL_T rRDDParam;
        	        struct SET_ADC_T rSetADC;
        	        struct SET_RX_GAIN_T rSetRxGain;
        	        struct SET_TTG_T rSetTTG;
        	        struct TTG_ON_OFF_T rTTGOnOff;
        	} Data;
	};

	struct CMD_TEST_CTRL_EXT_T {
        	uint8_t ucAction;
        	uint8_t ucIcapLen;
        	uint8_t aucReserved[2];
       		union {
       	         	uint32_t u4OpMode;
       		        uint32_t u4ChannelFreq;
        	        struct PARAM_MTK_WIFI_TEST_STRUCT_EXT_T rRfATInfo;
        	} u;
	};


enum ENUM_RF_AT_FUNCID {
        RF_AT_FUNCID_VERSION = 0,
        RF_AT_FUNCID_COMMAND,
};

enum ENUM_RF_AT_COMMAND {
        RF_AT_COMMAND_STOPTEST = 0,
        RF_AT_COMMAND_STARTTX,
        RF_AT_COMMAND_STARTRX,
        RF_AT_COMMAND_RESET,
        RF_AT_COMMAND_OUTPUT_POWER,     /* Payload */
        /* Local freq is renamed to Local leakage */
        RF_AT_COMMAND_LO_LEAKAGE,
        /* OFDM (LTF/STF), CCK (PI,PI/2) */
        RF_AT_COMMAND_CARRIER_SUPPR,
        RF_AT_COMMAND_TRX_IQ_CAL,
        RF_AT_COMMAND_TSSI_CAL,
        RF_AT_COMMAND_DPD_CAL,
        RF_AT_COMMAND_CW,
        RF_AT_COMMAND_ICAP,
        RF_AT_COMMAND_RDD,
        RF_AT_COMMAND_CH_SWITCH_FOR_ICAP,
        RF_AT_COMMAND_RESET_DUMP_NAME,
        RF_AT_COMMAND_SINGLE_TONE,
        RF_AT_COMMAND_RDD_OFF,
        RF_AT_COMMAND_NUM
};

int
mt7921_query_icap(void *data){
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;


        struct CMD_TEST_CTRL_EXT_T rCmdTestCtrl;
        struct PARAM_MTK_WIFI_TEST_STRUCT_EXT_T *prRfATInfo;
        uint32_t u4SetBufferLen = 0;
        void *pvSetBuffer = NULL;
        int32_t rStatus;

        prRfATInfo = &(rCmdTestCtrl.u.rRfATInfo);

        rCmdTestCtrl.ucAction = 1;
        prRfATInfo->u4FuncIndex = 0x11;
        prRfATInfo->Data.rICapDump.u4Address = 0;
        prRfATInfo->Data.rICapDump.u4AddrOffset = 0x04;
        prRfATInfo->Data.rICapDump.u4Bank = 1;
        prRfATInfo->Data.rICapDump.u4BankSize = 0;

        return mt76_mcu_send_msg(&dev->mt76, MCU_EXT_CMD(RF_TEST), &rCmdTestCtrl, sizeof(rCmdTestCtrl), false);
}

EXPORT_SYMBOL(mt7921_query_icap);

/* Trigger Event */
#define CAP_FREE_RUN            0

/* Ring Mode */
#define CAP_RING_MODE_ENABLE    1
#define CAP_RING_MODE_DISABLE   0

static int
mt7921_status_start_icap(void *data)
{
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;
	uint32_t u4Trigger 		= 1;
	uint32_t u4RingCapEn 		= 0;
	uint32_t u4Event 		= 0;
	uint32_t u4Node 		= 0x14000000;
	uint32_t u4Len 			= 0;
	uint32_t u4StopCycle 		= 10;
	uint32_t u4BW 			= 0;
	uint32_t u4MacTriggerEvent 	= 0x2000;
	uint32_t u4SourceAddrLSB 	= 0xefefefef;
	uint32_t u4SourceAddrMSB 	= 0x0001efef;
	uint32_t u4Band 		= 0;

        struct CMD_TEST_CTRL_EXT_T rCmdTestCtrl;
        struct RBIST_CAP_START_T *prCmdICapInfo;
        struct PARAM_MTK_WIFI_TEST_STRUCT_EXT_T *prRfATInfo;

        struct PARAM_MTK_WIFI_TEST_STRUCT_EXT_T rRfATInfo;
	struct RBIST_CAP_START_T *prICapInfo = NULL;

	prICapInfo			= (struct RBIST_CAP_START_T *)kmalloc(sizeof(struct RBIST_CAP_START_T), GFP_KERNEL);
        prICapInfo 			= &(rRfATInfo.Data.rICapInfo);
	prICapInfo->u4Trigger 		= u4Trigger;
	prICapInfo->u4TriggerEvent 	= u4Event;

        if (prICapInfo->u4TriggerEvent == CAP_FREE_RUN){
                prICapInfo->u4RingCapEn = CAP_RING_MODE_DISABLE;
        }else{
                prICapInfo->u4RingCapEn = CAP_RING_MODE_ENABLE;
	}

	prICapInfo->u4CaptureNode       = u4Node;
	prICapInfo->u4CaptureLen        = u4Len;
	prICapInfo->u4CapStopCycle      = u4StopCycle;
	prICapInfo->u4BW                = u4BW;
	prICapInfo->u4MacTriggerEvent   = u4MacTriggerEvent;
	prICapInfo->u4SourceAddressLSB  = u4SourceAddrLSB;
	prICapInfo->u4SourceAddressMSB  = u4SourceAddrMSB;
	prICapInfo->u4BandIdx           = u4Band;
	prICapInfo->u4EnBitWidth        = 4;
	prICapInfo->u4Architech         = 0;
	prICapInfo->u4PhyIdx            = 0;
	prICapInfo->u4EmiStartAddress   = 0;
	prICapInfo->u4EmiEndAddress     = 0;
	prICapInfo->u4EmiMsbAddress     = 0;
	prICapInfo->u4CapSource 	= 0;

	memset(&rCmdTestCtrl, 0x00, sizeof(struct CMD_TEST_CTRL_EXT_T));

        rCmdTestCtrl.ucAction 			= 1;
        rCmdTestCtrl.u.rRfATInfo.u4FuncIndex 	= 0x0B;

        prCmdICapInfo 				= &(rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo);

	memcpy(prCmdICapInfo, 	prICapInfo, 	sizeof(struct RBIST_CAP_START_T));
	mt76_mcu_send_msg(&dev->mt76, MCU_EXT_CMD(RF_TEST), &rCmdTestCtrl, sizeof(struct CMD_TEST_CTRL_EXT_T), false);
	return 0;
}

static int
mt7921_status_stop_icap(void *data)
{
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;
        uint32_t u4Trigger              = 0;
        uint32_t u4RingCapEn            = 0;
        uint32_t u4Event                = 0;
        uint32_t u4Node                 = 0x14000000;
        uint32_t u4Len                  = 0;
        uint32_t u4StopCycle            = 10;
        uint32_t u4BW                   = 0;
        uint32_t u4MacTriggerEvent      = 0x2000;
        uint32_t u4SourceAddrLSB        = 0xefefefef;
        uint32_t u4SourceAddrMSB        = 0x0001efef;
        uint32_t u4Band                 = 0;

        struct RBIST_CAP_START_T *prICapInfo = NULL;

        struct CMD_TEST_CTRL_EXT_T rCmdTestCtrl;
        struct RBIST_CAP_START_T *prCmdICapInfo;
        struct PARAM_MTK_WIFI_TEST_STRUCT_EXT_T *prRfATInfo;

        memset(&rCmdTestCtrl, 0x00, sizeof(struct CMD_TEST_CTRL_EXT_T));

        rCmdTestCtrl.ucAction                   = 1;
        rCmdTestCtrl.u.rRfATInfo.u4FuncIndex    = 0x0B;

        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4Trigger           = u4Trigger;
    	rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4TriggerEvent      = u4Event;

        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4RingCapEn         = 1; // CAP_RING_MODE_ENABLE

        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4CaptureNode       = u4Node;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4CaptureLen        = u4Len;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4CapStopCycle      = u4StopCycle;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4BW                = u4BW;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4MacTriggerEvent   = u4MacTriggerEvent;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4SourceAddressLSB  = u4SourceAddrLSB;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4SourceAddressMSB  = u4SourceAddrMSB;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4BandIdx           = u4Band;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4EnBitWidth        = 4;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4Architech         = 0;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4PhyIdx            = 0;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4EmiStartAddress   = 0;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4EmiEndAddress     = 0;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4EmiMsbAddress     = 0;
        rCmdTestCtrl.u.rRfATInfo.Data.rICapInfo.u4CapSource         = 0;
        return mt76_mcu_send_msg(&dev->mt76, MCU_EXT_CMD(RF_TEST), &rCmdTestCtrl, sizeof(struct CMD_TEST_CTRL_EXT_T), false);
}


static int
mt7921_ate_stop(void *data)
{
        signed int ret                  = 0x00;
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;

	struct mt7921_rftest_cmd cmd = {
        	.action = 0x00,                                 /** switch   **/
        	.param0 = (0x00),                    /** normal   **/
        	.param1 = (0x00),                    /** NULL     **/
	};

	ret = mt76_mcu_send_msg(&dev->mt76, MCU_CE_CMD(TEST_CTRL), &cmd, sizeof(cmd), false);
	return ret;
}

static int
mt7921_ate_start(void *data)
{
        signed int ret                  = 0x00;
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;

        struct mt7921_rftest_cmd cmd = {
                .action = 0x00,                                 /** switch   **/
                .param0 = (0x01),                    /** normal   **/
                .param1 = (0x00),                    /** NULL     **/
        };

        ret = mt76_mcu_send_msg(&dev->mt76, MCU_CE_CMD(TEST_CTRL), &cmd, sizeof(cmd), false);
	return ret;
}

static int
mt7921_icap_start(void *data)
{
        signed int ret                  = 0x00;
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;

	struct mt7921_rftest_cmd cmd = {
        	.action = 0x00,                       /** switch   **/
        	.param0 = (0x02),                     /** icap     **/
        	.param1 = (0x00),                     /** NULL     **/
	};

	ret = mt76_mcu_send_msg(&dev->mt76, MCU_CE_CMD(TEST_CTRL), &cmd, sizeof(cmd), false);
	return ret;
}

static int
mt7921_txframe_start(void *data)
{
        signed int ret                  = 0x00;
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;

	struct mt7921_rftest_cmd cmd = {
	        .action = 0x01,                                 /** set AT   **/
	        .param0 = (RF_AT_FUNCID_COMMAND),    /** NULL     **/
	        .param1 = (RF_AT_COMMAND_STARTTX),   /** NULL     **/
	};

	ret = mt76_mcu_send_msg(&dev->mt76, MCU_CE_CMD(TEST_CTRL), &cmd, sizeof(cmd), false);
	return ret;
}

static int
mt7921_txframe_stop(void *data)
{
        signed int ret                  = 0x00;
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;

        struct mt7921_rftest_cmd cmd = {
                .action = 0x01,                                 /** set AT   **/
                .param0 = (RF_AT_FUNCID_COMMAND),    /** NULL     **/
                .param1 = (RF_AT_COMMAND_STOPTEST),  /** NULL     **/
        };

        ret = mt76_mcu_send_msg(&dev->mt76, MCU_CE_CMD(TEST_CTRL), &cmd, sizeof(cmd), false);
        return ret;
}

static int
mt7921_rxframe_start(void *data)
{
        signed int ret                  = 0x00;
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;

        struct mt7921_rftest_cmd cmd = {
                .action = 0x01,                                 /** set AT   **/
                .param0 = (RF_AT_FUNCID_COMMAND),    /** NULL     **/
                .param1 = (RF_AT_COMMAND_STARTRX),   /** NULL     **/
        };

        ret = mt76_mcu_send_msg(&dev->mt76, MCU_CE_CMD(TEST_CTRL), &cmd, sizeof(cmd), false);
        return ret;
}

static int
mt7921_rxframe_stop(void *data)
{
	signed int ret			= 0x00;
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;

        struct mt7921_rftest_cmd cmd = {
                .action = 0x01,                                 /** set AT   **/
                .param0 = (RF_AT_FUNCID_COMMAND),    /** NULL     **/
                .param1 = (RF_AT_COMMAND_STOPTEST),  /** NULL     **/
        };

        ret = mt76_mcu_send_msg(&dev->mt76, MCU_CE_CMD(TEST_CTRL), &cmd, sizeof(cmd), false);
        return ret;
}


static int
mt7921_set_icap(void *data, u64 val)
{
        struct mt792x_dev *dev		= (struct mt792x_dev *)data;
	//mutex_lock(&dev->mt76.mutex);
	/**
	if( val == 0 ){
		mt7921_ate_start(data);
	}else if( val == 1 ){
		mt7921_icap_start(data);
	}else if( val == 2 ){
		mt7921_status_start_icap(data);
	}else if( val == 3 ){
		mt7921_rxframe_start(data);
	}else if( val == 4 ){
		mt7921_rxframe_stop(data);
	}else if( val == 5 ){
		mt7921_ate_stop(data);
	}else if( val == 6 ){
		mt7921_txframe_start(data);
	}else if( val == 7 ){
		mt7921_txframe_stop(data);
	}
	**/

	//mt7921_ate_start(data);
	mt7921_icap_start(data);
	mt7921_status_start_icap(data);
        mt7921_rxframe_start(data);
	mt7921_txframe_start(data);
	mt7921_query_icap(data);
out:
        //mutex_unlock(&dev->mt76.mutex);
	return 0;
}

static int
mt7921_set_icap_freq(void *data)
{
	struct mt792x_dev *dev          = (struct mt792x_dev *)data;
        struct mt7921_rftest_cmd cmd    = {
                .action = 5,
                .param0 = 2412000,
                .param1 = 0x0,
        };

        return mt76_mcu_send_msg(&dev->mt76, MCU_CE_CMD(TEST_CTRL), &cmd, sizeof(cmd), false);
}

static int
mt7921_get_icap(void *data, u64 *val)
{
	mt7921_query_icap(data);
	return 0;
        struct mt792x_dev *dev          = (struct mt792x_dev *)data;
        struct mt7921_tm_cmd *req       = (struct mt7921_tm_cmd *)kmalloc(sizeof(struct mt7921_tm_cmd), GFP_KERNEL);
        req->action                     = TM_SWITCH_MODE;
        req->param0                     = val;
        req->param1                     = 0x2;

        struct mt7921_rftest_cmd cmd    = {
                .action = TM_SWITCH_MODE,
                .param0 = val,
                .param1 = 0x2,
        };

	mt7921_status_start_icap(data);

        bool testmode = false, normal   = false;
        struct mt76_connac_pm *pm       = &dev->pm;
        struct mt76_phy *phy            = &dev->mphy;
        int ret                         = -ENOTCONN;

        mutex_lock(&dev->mt76.mutex);

        if (req->action == TM_SWITCH_MODE) {
                if (req->param0 == MT7921_TM_NORMAL)
                        normal = true;
                else
                        testmode = true;
        }

        if (testmode) {
                /* Make sure testmode running on full power mode */
                pm->enable = false;
                cancel_delayed_work_sync(&pm->ps_work);
                cancel_work_sync(&pm->wake_work);
                __mt792x_mcu_drv_pmctrl(dev);
                phy->test.state = MT76_TM_STATE_ON;
        }

        //if (!mt76_testmode_enabled(phy)){
          //      goto out;
        //}

        ret = mt76_mcu_send_msg(&dev->mt76, MCU_CE_CMD(TEST_CTRL), &cmd, sizeof(cmd), false);

        if (ret){
                goto out;
        }

        if (normal) {
                /* Switch back to the normal world */
                phy->test.state = MT76_TM_STATE_OFF;
                pm->enable = true;
        }
out:
        kfree(req);
        mutex_unlock(&dev->mt76.mutex);
        return 0;
}

DEFINE_DEBUGFS_ATTRIBUTE(fops_icap, mt7921_get_icap, mt7921_set_icap, "0x%08llx\n");

struct PARAM_CUSTOM_ICS_SNIFFER_INFO_STRUCT {
        /* Include system all and PSSniffer */
        uint8_t ucModule;
        uint8_t ucAction;
        uint8_t ucFilter;
        uint8_t ucOperation;
        uint16_t ucCondition[7];
        uint8_t aucPadding0[62];
};

#define MAC_ICS_MODE            2
#define PHY_ICS_MODE            3

struct CMD_ICS_SNIFFER_INFO {
        /* DWORD_0 - Common Part*/
        /*Include system all and PSSniffer */
        uint8_t ucCmdVer;
        uint8_t ucAction;
        uint16_t u2CmdLen;
        /* DWORD_1 ~ x */
        uint8_t ucModule;
        uint8_t ucFilter;
        uint8_t ucOperation;
        uint8_t aucPadding0;
        uint16_t ucCondition[7];
        uint8_t aucPadding1[62];
};

static int
mt7921_get_ics(void *data, u64 *val)
{
	struct mt792x_dev *dev          = (struct mt792x_dev *)data;
	struct CMD_ICS_SNIFFER_INFO req = {
		.ucModule		= 0x03,
		.ucAction		= 0x01,
		.ucFilter		= 0x00,
		.ucOperation		= 0x01,
		.ucCondition[0]		= 0x04,
		.ucCondition[3]         = 0x00,
	};
        return mt76_mcu_send_msg(&dev->mt76, 0x93, &req, sizeof(req), false);
}

DEFINE_DEBUGFS_ATTRIBUTE(fops_ics, mt7921_get_ics, NULL, "0x%08llx\n");

struct CMD_CSI_CONTROL_T {
        uint8_t ucBandIdx;
        uint8_t ucMode;
        uint8_t ucCfgItem;
        uint8_t ucValue1;
        uint8_t ucValue2;
};

enum ENUM_DBDC_BN {
        ENUM_BAND_0,
        ENUM_BAND_1,
        ENUM_BAND_NUM,
#if (CFG_SUPPORT_CONNAC3X == 0)
        ENUM_BAND_ALL,
        ENUM_BAND_AUTO  /*Auto select by A/G band, Driver only*/
#else
        ENUM_BAND_ALL = 0xFE,
        ENUM_BAND_AUTO = 0xFF,
#endif
};

enum CSI_CONTROL_MODE_T {
        CSI_CONTROL_MODE_STOP,
        CSI_CONTROL_MODE_START,
        CSI_CONTROL_MODE_SET,
        CSI_CONTROL_MODE_NUM
};


static int
mt7921_get_csi(void *data, u64 *val){
        struct mt792x_dev *dev = data;

	struct CMD_CSI_CONTROL_T req = {
		.ucBandIdx = ENUM_BAND_0,
		.ucMode	   = CSI_CONTROL_MODE_START,
	};

	return mt76_mcu_send_msg(&dev->mt76, 0xC2, &req, sizeof(req), false);
}

DEFINE_DEBUGFS_ATTRIBUTE(fops_csi, mt7921_get_csi, NULL, "0x%08llx\n");

static int
mt7921_fw_debug_set(void *data, u64 val)
{
	struct mt792x_dev *dev = data;

	mt792x_mutex_acquire(dev);

	dev->fw_debug = (u8)val;
	mt7921_mcu_fw_log_2_host(dev, dev->fw_debug);

	mt792x_mutex_release(dev);

	return 0;
}

static int
mt7921_fw_debug_get(void *data, u64 *val)
{
	struct mt792x_dev *dev = data;

	*val = dev->fw_debug;

	return 0;
}

DEFINE_DEBUGFS_ATTRIBUTE(fops_fw_debug, mt7921_fw_debug_get,
			 mt7921_fw_debug_set, "%lld\n");

DEFINE_SHOW_ATTRIBUTE(mt792x_tx_stats);

static void
mt7921_seq_puts_array(struct seq_file *file, const char *str,
		      s8 *val, int len)
{
	int i;

	seq_printf(file, "%-16s:", str);
	for (i = 0; i < len; i++)
		if (val[i] == 127)
			seq_printf(file, " %6s", "N.A");
		else
			seq_printf(file, " %6d", val[i]);
	seq_puts(file, "\n");
}

#define mt7921_print_txpwr_entry(prefix, rate)				\
({									\
	mt7921_seq_puts_array(s, #prefix " (user)",			\
			      txpwr.data[TXPWR_USER].rate,		\
			      ARRAY_SIZE(txpwr.data[TXPWR_USER].rate)); \
	mt7921_seq_puts_array(s, #prefix " (eeprom)",			\
			      txpwr.data[TXPWR_EEPROM].rate,		\
			      ARRAY_SIZE(txpwr.data[TXPWR_EEPROM].rate)); \
	mt7921_seq_puts_array(s, #prefix " (tmac)",			\
			      txpwr.data[TXPWR_MAC].rate,		\
			      ARRAY_SIZE(txpwr.data[TXPWR_MAC].rate));	\
})

static int
mt7921_txpwr(struct seq_file *s, void *data)
{
	struct mt792x_dev *dev = dev_get_drvdata(s->private);
	struct mt7921_txpwr txpwr;
	int ret;

	mt792x_mutex_acquire(dev);
	ret = mt7921_get_txpwr_info(dev, &txpwr);
	mt792x_mutex_release(dev);

	if (ret)
		return ret;

	seq_printf(s, "Tx power table (channel %d)\n", txpwr.ch);
	seq_printf(s, "%-16s  %6s %6s %6s %6s\n",
		   " ", "1m", "2m", "5m", "11m");
	mt7921_print_txpwr_entry(CCK, cck);

	seq_printf(s, "%-16s  %6s %6s %6s %6s %6s %6s %6s %6s\n",
		   " ", "6m", "9m", "12m", "18m", "24m", "36m",
		   "48m", "54m");
	mt7921_print_txpwr_entry(OFDM, ofdm);

	seq_printf(s, "%-16s  %6s %6s %6s %6s %6s %6s %6s %6s\n",
		   " ", "mcs0", "mcs1", "mcs2", "mcs3", "mcs4", "mcs5",
		   "mcs6", "mcs7");
	mt7921_print_txpwr_entry(HT20, ht20);

	seq_printf(s, "%-16s  %6s %6s %6s %6s %6s %6s %6s %6s %6s\n",
		   " ", "mcs0", "mcs1", "mcs2", "mcs3", "mcs4", "mcs5",
		   "mcs6", "mcs7", "mcs32");
	mt7921_print_txpwr_entry(HT40, ht40);

	seq_printf(s, "%-16s  %6s %6s %6s %6s %6s %6s %6s %6s %6s %6s %6s %6s\n",
		   " ", "mcs0", "mcs1", "mcs2", "mcs3", "mcs4", "mcs5",
		   "mcs6", "mcs7", "mcs8", "mcs9", "mcs10", "mcs11");
	mt7921_print_txpwr_entry(VHT20, vht20);
	mt7921_print_txpwr_entry(VHT40, vht40);
	mt7921_print_txpwr_entry(VHT80, vht80);
	mt7921_print_txpwr_entry(VHT160, vht160);
	mt7921_print_txpwr_entry(HE26, he26);
	mt7921_print_txpwr_entry(HE52, he52);
	mt7921_print_txpwr_entry(HE106, he106);
	mt7921_print_txpwr_entry(HE242, he242);
	mt7921_print_txpwr_entry(HE484, he484);
	mt7921_print_txpwr_entry(HE996, he996);
	mt7921_print_txpwr_entry(HE996x2, he996x2);

	return 0;
}

static int
mt7921_pm_set(void *data, u64 val)
{
	struct mt792x_dev *dev = data;
	struct mt76_connac_pm *pm = &dev->pm;

	if (mt76_is_usb(&dev->mt76))
		return -EOPNOTSUPP;

	mutex_lock(&dev->mt76.mutex);

	if (val == pm->enable_user)
		goto out;

	if (!pm->enable_user) {
		pm->stats.last_wake_event = jiffies;
		pm->stats.last_doze_event = jiffies;
	}
	/* make sure the chip is awake here and ps_work is scheduled
	 * just at end of the this routine.
	 */
	pm->enable = false;
	mt76_connac_pm_wake(&dev->mphy, pm);

	pm->enable_user = val;
	mt7921_set_runtime_pm(dev);
	mt76_connac_power_save_sched(&dev->mphy, pm);
out:
	mutex_unlock(&dev->mt76.mutex);

	return 0;
}

static int
mt7921_pm_get(void *data, u64 *val)
{
	struct mt792x_dev *dev = data;

	*val = dev->pm.enable_user;

	return 0;
}

DEFINE_DEBUGFS_ATTRIBUTE(fops_pm, mt7921_pm_get, mt7921_pm_set, "%lld\n");

static int
mt7921_deep_sleep_set(void *data, u64 val)
{
	struct mt792x_dev *dev = data;
	struct mt76_connac_pm *pm = &dev->pm;
	bool monitor = !!(dev->mphy.hw->conf.flags & IEEE80211_CONF_MONITOR);
	bool enable = !!val;

	if (mt76_is_usb(&dev->mt76))
		return -EOPNOTSUPP;

	mt792x_mutex_acquire(dev);
	if (pm->ds_enable_user == enable)
		goto out;

	pm->ds_enable_user = enable;
	pm->ds_enable = enable && !monitor;
	mt76_connac_mcu_set_deep_sleep(&dev->mt76, pm->ds_enable);
out:
	mt792x_mutex_release(dev);

	return 0;
}

static int
mt7921_deep_sleep_get(void *data, u64 *val)
{
	struct mt792x_dev *dev = data;

	*val = dev->pm.ds_enable_user;

	return 0;
}

DEFINE_DEBUGFS_ATTRIBUTE(fops_ds, mt7921_deep_sleep_get,
			 mt7921_deep_sleep_set, "%lld\n");

DEFINE_DEBUGFS_ATTRIBUTE(fops_pm_idle_timeout, mt792x_pm_idle_timeout_get,
			 mt792x_pm_idle_timeout_set, "%lld\n");

static int mt7921_chip_reset(void *data, u64 val)
{
	struct mt792x_dev *dev = data;
	int ret = 0;

	switch (val) {
	case 1:
		/* Reset wifisys directly. */
		mt792x_reset(&dev->mt76);
		break;
	default:
		/* Collect the core dump before reset wifisys. */
		mt792x_mutex_acquire(dev);
		ret = mt76_connac_mcu_chip_config(&dev->mt76);
		mt792x_mutex_release(dev);
		break;
	}

	return ret;
}

DEFINE_DEBUGFS_ATTRIBUTE(fops_reset, NULL, mt7921_chip_reset, "%lld\n");

static int
mt7921s_sched_quota_read(struct seq_file *s, void *data)
{
	struct mt792x_dev *dev = dev_get_drvdata(s->private);
	struct mt76_sdio *sdio = &dev->mt76.sdio;

	seq_printf(s, "pse_data_quota\t%d\n", sdio->sched.pse_data_quota);
	seq_printf(s, "ple_data_quota\t%d\n", sdio->sched.ple_data_quota);
	seq_printf(s, "pse_mcu_quota\t%d\n", sdio->sched.pse_mcu_quota);
	seq_printf(s, "sched_deficit\t%d\n", sdio->sched.deficit);

	return 0;
}

int mt7921_init_debugfs(struct mt792x_dev *dev)
{
	struct dentry *dir;

	dir = mt76_register_debugfs_fops(&dev->mphy, &fops_regval);
	if (!dir)
		return -ENOMEM;

	if (mt76_is_mmio(&dev->mt76))
		debugfs_create_devm_seqfile(dev->mt76.dev, "xmit-queues",
					    dir, mt792x_queues_read);
	else
		debugfs_create_devm_seqfile(dev->mt76.dev, "xmit-queues",
					    dir, mt76_queues_read);

	debugfs_create_devm_seqfile(dev->mt76.dev, "acq", dir,
				    mt792x_queues_acq);
	debugfs_create_devm_seqfile(dev->mt76.dev, "txpower_sku", dir,
				    mt7921_txpwr);
	debugfs_create_file("tx_stats", 0400, dir, dev, &mt792x_tx_stats_fops);
	debugfs_create_file("fw_debug", 0600, dir, dev, &fops_fw_debug);
	debugfs_create_file("runtime-pm", 0600, dir, dev, &fops_pm);
	debugfs_create_file("idle-timeout", 0600, dir, dev,
			    &fops_pm_idle_timeout);

	debugfs_create_file("icap", 0600, dir, dev, &fops_icap);
        debugfs_create_file("ics", 0600, dir, dev, &fops_ics);
	debugfs_create_file("csi", 0600, dir, dev, &fops_csi);
	debugfs_create_file("chip_reset", 0600, dir, dev, &fops_reset);
	debugfs_create_devm_seqfile(dev->mt76.dev, "runtime_pm_stats", dir,
				    mt792x_pm_stats);
	debugfs_create_file("deep-sleep", 0600, dir, dev, &fops_ds);

	debugfs_create_devm_seqfile(dev->mt76.dev, "mt76_show_pc", dir, mt76_cpu_state_get);
	if (mt76_is_sdio(&dev->mt76))
		debugfs_create_devm_seqfile(dev->mt76.dev, "sched-quota", dir,
					    mt7921s_sched_quota_read);
	return 0;
}
