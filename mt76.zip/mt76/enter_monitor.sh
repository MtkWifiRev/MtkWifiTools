sudo iw phy phy1 interface add mon0 type monitor
sudo ifconfig mon0 up
