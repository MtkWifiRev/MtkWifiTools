make -j16 #EXTRA_CFLAGS=-DCONFIG_NL80211_TESTMODE

sudo rmmod  mt7921e
sudo rmmod  mt7921-common
sudo rmmod  mt792x-lib
sudo rmmod  mt76_connac_lib
sudo rmmod  mt76

sudo insmod mt76.ko
sudo insmod mt76-connac-lib.ko
sudo insmod mt792x-lib.ko
sudo insmod mt7921/mt7921-common.ko
sudo insmod mt7921/mt7921e.ko
