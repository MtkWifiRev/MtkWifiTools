gcc -c fwlog.c  -I./libnl-tiny/include/
gcc -c eeprom.c -I./libnl-tiny/include/
gcc -c fields.c -I./libnl-tiny/include/
gcc main.c -o mt76-test *.o -I./libnl-tiny/include/ libnl-tiny/libnl-tiny.a
